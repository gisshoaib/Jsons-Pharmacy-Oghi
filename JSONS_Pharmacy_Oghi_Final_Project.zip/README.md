
# JSONS Pharmacy Oghi

Flutter customer ordering app starter.

Features planned:
- Customer details
- Multiple medicine orders
- Offline storage ready
- Firebase sync ready

Build with Flutter to create APK.
